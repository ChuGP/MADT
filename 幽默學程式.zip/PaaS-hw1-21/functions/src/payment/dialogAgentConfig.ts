export const DIALOGFLOW = {
    path: "PaaS-hw1-21-f0789b7eb3aa.json",
    projectId: "paas-hw1-21-232110",
    languageCode: 'zh-TW'
}

export const ASSISTANT = {
    username: "apikey",
    password: "URAWWPniMLDUTDeyBSvyhEFaa6vcdU15gmJsvV8SFsx_",
    url: "https://gateway.watsonplatform.net/assistant/api",
    version: "2018-11-08",
    assistantId: "75f77424-9eb2-453e-b7e3-e52a897b6aa6"
}

export const sessionServiceUrl = "https://us-central1-paas-hw1-21-232110.cloudfunctions.net/"
