export const shop = {
    id: "12",
    name: "街口支付",
    line: {
        channelId: "1557365185",
        channelSecret: "00f771b1f459f43c9a74df6584441f77"
    }
}
export const ASSISTANT = {
    username: "apikey",
    password: "URAWWPniMLDUTDeyBSvyhEFaa6vcdU15gmJsvV8SFsx_",
    url: "https://gateway.watsonplatform.net/assistant/api",
    version: "2018-11-08",
    assistantId: "75f77424-9eb2-453e-b7e3-e52a897b6aa6"
}

export const carrierShopId = "13"

export const mallFlowUrl = "https://us-central1-paas-hw1-21-232110.cloudfunctions.net/"
export const handoverUrl = "https://us-central1-paas-hw1-21-232110.cloudfunctions.net/"
export const sessionServiceUrl = "https://us-central1-paas-hw1-21-232110.cloudfunctions.net/"

export const pubsubConfig = {
    serviceAccountPath: "pubsubServiceAccountKey.json",
    subPath: "projects/paas-hw1-21-232110/subscriptions/"
}

export const paymentSubName = "handOverPaymentSub"
export const shopTopicName = "shopTopic"