export const pubsubConfig = {
    serviceAccountPath: "pubsubServiceAccountKey.json",
    topicPath: "projects/paas-hw1-21-232110/topics/"
 }

export const shopTopicName = "shopTopic"