export const  topicName = "test"

export const shops = [
    {
        shopId: "107598009",
        name: "智能保險",
        line: {
            channelId: "1649585264",
            channelSecret: "0d56dae98a0f6bfb3a8b2ec4a5b674cd",
        }
    },
    {
        shopId: "106598016",
        name: "街口支付",
        line: {
            channelId: "1557365185",
            channelSecret: "00f771b1f459f43c9a74df6584441f77",
        }
    }
]