export const shop = {
    id: "11",
    name: "智能保險",
    line: {
        channelId: "1649585264",
        channelSecret: "048a4f61325bff73a182473a99d29adf"
    }
}

export const DIALOGFLOW = {
    path: "PaaS-hw1-21-f0789b7eb3aa.json",
    projectId: "paas-hw1-21-232110",
    languageCode: 'zh-CN'
}

export const paymentShopId = "12"

export const mallFlowUrl = "https://us-central1-paas-hw1-21-232110.cloudfunctions.net/"
export const handoverUrl = "https://us-central1-paas-hw1-21-232110.cloudfunctions.net/"

export const pubsubConfig = {
    serviceAccountPath: "pubsubServiceAccountKey.json",
    subPath: "projects/paas-hw1-21-232110/subscriptions/"
}

export const shopTopicName = "shopTopic"
export const insuranceSubName = "handOverInsuranceSub"
