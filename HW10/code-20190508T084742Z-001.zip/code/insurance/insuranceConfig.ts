export const shop = {
    id: "11",
    name: "智能保險",
    line: {
        channelId: "",
        channelSecret: ""
    }
}

export const DIALOGFLOW = {
    path: "serviceAccountKey.json",
    projectId: "",
    languageCode: 'zh-CN'
}

export const APIGEE = {
    url:"",
    apikey:""
}
export const mallFlowUrl = APIGEE.url
//export const mallFlowUrl = ""
export const mallServiceUrl = ""

export const paymentShopId = "12"

export const pubsubConfig = {
    serviceAccountPath: "pubsubServiceAccountKey.json",
    subPath: ""
}

export const insuranceSubName = "handOverInsuranceSub"
