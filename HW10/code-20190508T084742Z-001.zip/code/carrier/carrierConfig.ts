export const shop = {
    id: "13",
    name: "黑貓宅配",
    weChat: {
        appid: "",
        appSecret: "",
        token: "",
        checkSignature: true
    }
}
export const ASSISTANT = {
    username: "apikey",
    password: "",
    url: "https://gateway.watsonplatform.net/assistant/api/",
    version: "2018-11-08",
    assistantId: ""
}

export const APIGEE = {
    url:"",
    apikey:""
}
export const mallFlowUrl = APIGEE.url
//export const mallFlowUrl = ""
export const mallServiceUrl = ""
export const sessionServiceUrl = ""

export const pubsubConfig = {
    serviceAccountPath: "pubsubServiceAccountKey.json",
    subPath: ""
}

export const CarrySubName = "handOverCarrySub"