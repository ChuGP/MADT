export const pubsubConfig = {
    serviceAccountPath: "pubsubServiceAccountKey.json",
    topicPath: ""
 }

export const shopTopicName = "shopTopic"