export type handoverModel = {
    transactionId:string
    fromShopId:string
    toShopId:string
    event:string
    customerId:string
    key:any
    value:any
}