export const mallServiceUrl = "https://us-central1-.cloudfunctions.net/"

// insurance
export const shop11ServiceUrl = "https://us-central1-.cloudfunctions.net/"
// payment
export const shop12ServiceUrl = "https://us-central1-.cloudfunctions.net/"
// carrier
export const shop13ServiceUrl = "https://us-central1-.cloudfunctions.net/"
// 3C
export const shop14ServiceUrl = "https://us-central1-.cloudfunctions.net/"