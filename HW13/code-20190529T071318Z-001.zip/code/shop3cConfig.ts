export const shop = {
    id: "14",
    name: "智能3c",
    line: {
        channelId: "1648176076",
        channelSecret: "87fed6c7d036c63e08cbf0f3382aabab"
    }
}

export const ASSISTANT = {
    username: "apikey",
    password: "ls7d2-F548FvSXjhdAmYblGF9mlQKqprAybxTf9CGl3k",
    url: "https://gateway.watsonplatform.net/assistant/api/",
    version: "2018-11-08",
    assistantId: "49016ff1-4101-419f-8bcc-9377c76bef79"
}

export const APIGEE = {
    url: "https://paastaipeitech-eval-test.apigee.net/",
    apikey: "zXG5KjjHrqOoQYG3wLqDrraczoAmk8Oj"
}

// export const mallFlowUrl = APIGEE.url
export const mallFlowUrl = "https://c5443c44.ngrok.io/apps-228904/us-central1/"
//export const sessionServiceUrl = "https://us-central1-apps-228904.cloudfunctions.net/"
export const sessionServiceUrl = "https://c5443c44.ngrok.io/apps-228904/us-central1/"