export const mallServiceUrl = "https://us-central1-apps-228904.cloudfunctions.net/"

export const blockChainUrl = "your_stratoUrl"

export const iMallAccount = {
    name: "superUserName",
    password: "your_iMallAccountassword",
    token: "your_iMallAccountToken",
    address: "your_iMallAccountAddress"
}

export const accountBalanceContract = {
    name: "AccountBalance",
    address: "your_accountBalanceContractAddress"
}